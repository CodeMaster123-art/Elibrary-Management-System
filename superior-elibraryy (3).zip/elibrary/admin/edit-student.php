<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Edit Student';

$id = (int)($_GET['id'] ?? 0);
$stmt = $dbh->prepare("SELECT * FROM tbl_students WHERE id=:id");
$stmt->execute([':id' => $id]);
$student = $stmt->fetch();
if (!$student) { header('Location: manage-students.php'); exit; }

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Update profile
    if (isset($_POST['update'])) {
        $full_name  = trim($_POST['full_name'] ?? '');
        $email      = trim($_POST['email'] ?? '');
        $phone      = trim($_POST['phone'] ?? '');
        $department = trim($_POST['department'] ?? '');
        try {
            $dbh->prepare("UPDATE tbl_students SET full_name=:n, email=:e, phone=:p, department=:d WHERE id=:id")
                ->execute([':n'=>$full_name,':e'=>$email,':p'=>$phone,':d'=>$department,':id'=>$id]);
            $success = 'Student profile updated.';
            // refresh
            $stmt = $dbh->prepare("SELECT * FROM tbl_students WHERE id=:id");
            $stmt->execute([':id'=>$id]);
            $student = $stmt->fetch();
        } catch (PDOException $e) {
            $error = 'Email already in use by another student.';
        }
    }

    // Reset password
    if (isset($_POST['reset_pass'])) {
        $new_pass = $_POST['new_password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';
        if (strlen($new_pass) < 6) {
            $error = 'Password must be at least 6 characters.';
        } elseif ($new_pass !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            $hashed = password_hash($new_pass, PASSWORD_DEFAULT);
            $dbh->prepare("UPDATE tbl_students SET password=:p WHERE id=:id")->execute([':p'=>$hashed,':id'=>$id]);
            $success = 'Password reset successfully.';
        }
    }
}
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title d-flex justify-between align-center">
    <div><h2>Edit Student</h2><p><?= htmlspecialchars($student->full_name) ?> — <?= htmlspecialchars($student->student_id) ?></p></div>
    <a href="manage-students.php" class="btn btn-secondary">← Back</a>
</div>

<?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="row">
    <div class="col-6">
        <div class="el-card" style="margin-bottom:20px;">
            <div class="el-card-header">✏️ Edit Profile</div>
            <div class="el-card-body">
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Student ID</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($student->student_id) ?>" disabled style="background:#f5f0fa;">
                        <small class="text-muted">Student ID cannot be changed</small>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Full Name *</label>
                        <input type="text" name="full_name" class="form-control" required value="<?= htmlspecialchars($student->full_name) ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" class="form-control" required value="<?= htmlspecialchars($student->email) ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Phone</label>
                        <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($student->phone ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Department</label>
                        <input type="text" name="department" class="form-control" value="<?= htmlspecialchars($student->department ?? '') ?>">
                    </div>
                    <button type="submit" name="update" class="btn btn-primary">💾 Save Changes</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-6">
        <div class="el-card">
            <div class="el-card-header">🔒 Reset Password</div>
            <div class="el-card-body">
                <p style="font-size:13px;color:#7a6b8a;margin-bottom:16px;">Set a new password for this student and share it with them.</p>
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">New Password *</label>
                        <input type="password" name="new_password" class="form-control" placeholder="Min 6 characters" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Confirm Password *</label>
                        <input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required>
                    </div>
                    <button type="submit" name="reset_pass" class="btn btn-warning">🔒 Reset Password</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
