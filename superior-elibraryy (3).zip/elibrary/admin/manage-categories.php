<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Manage Categories';

$error = $success = '';

// Add
if (isset($_POST['add'])) {
    $name = trim($_POST['category_name'] ?? '');
    if ($name) {
        try {
            $dbh->prepare("INSERT INTO tbl_categories (category_name) VALUES (:n)")->execute([':n'=>$name]);
            $success = 'Category added successfully.';
        } catch (PDOException $e) { $error = 'Category already exists.'; }
    }
}

// Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $check = $dbh->prepare("SELECT COUNT(*) FROM tbl_books WHERE category_id=:id");
    $check->execute([':id'=>$id]);
    if ($check->fetchColumn() > 0) {
        $error = 'Cannot delete: books exist in this category.';
    } else {
        $dbh->prepare("DELETE FROM tbl_categories WHERE id=:id")->execute([':id'=>$id]);
        $success = 'Category deleted.';
    }
}

// Toggle status
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $dbh->prepare("UPDATE tbl_categories SET status = 1 - status WHERE id=:id")->execute([':id'=>$id]);
    header('Location: manage-categories.php'); exit;
}

// Edit
if (isset($_POST['edit'])) {
    $id = (int)$_POST['edit_id'];
    $name = trim($_POST['edit_name'] ?? '');
    if ($name) {
        $dbh->prepare("UPDATE tbl_categories SET category_name=:n WHERE id=:id")->execute([':n'=>$name,':id'=>$id]);
        $success = 'Category updated.';
    }
}

$categories = $dbh->query("SELECT c.*, COUNT(b.id) as book_count FROM tbl_categories c LEFT JOIN tbl_books b ON b.category_id=c.id GROUP BY c.id ORDER BY c.id DESC")->fetchAll();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title"><h2>Manage Categories</h2><p>Organise books by subject area</p></div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="row">
    <div class="col-6" style="max-width:380px;">
        <div class="el-card">
            <div class="el-card-header">➕ Add Category</div>
            <div class="el-card-body">
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Category Name *</label>
                        <input type="text" name="category_name" class="form-control" placeholder="e.g. Computer Science" required>
                    </div>
                    <button type="submit" name="add" class="btn btn-primary btn-full">Add Category</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-6" style="flex:1;">
        <div class="el-card">
            <div class="el-card-header">🏷️ All Categories (<?= count($categories) ?>)</div>
            <div class="p-0">
                <?php if ($categories): ?>
                <table class="el-table">
                    <thead><tr><th>#</th><th>Category Name</th><th>Books</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php $n=1; foreach ($categories as $c): ?>
                        <tr>
                            <td><?= $n++ ?></td>
                            <td>
                                <form method="POST" style="display:flex;gap:6px;align-items:center;">
                                    <input type="hidden" name="edit_id" value="<?= $c->id ?>">
                                    <input type="text" name="edit_name" class="form-control" value="<?= htmlspecialchars($c->category_name) ?>" style="padding:5px 8px;font-size:13px;">
                                    <button type="submit" name="edit" class="btn btn-warning btn-sm">💾</button>
                                </form>
                            </td>
                            <td><span class="badge badge-primary"><?= $c->book_count ?></span></td>
                            <td>
                                <a href="?toggle=<?= $c->id ?>">
                                    <?= $c->status ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>' ?>
                                </a>
                            </td>
                            <td>
                                <a href="?delete=<?= $c->id ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this category?')">🗑️</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="no-data">No categories yet.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
