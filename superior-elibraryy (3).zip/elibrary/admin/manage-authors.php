<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Manage Authors';

$error = $success = '';

if (isset($_POST['add'])) {
    $name = trim($_POST['author_name'] ?? '');
    if ($name) {
        try {
            $dbh->prepare("INSERT INTO tbl_authors (author_name) VALUES (:n)")->execute([':n'=>$name]);
            $success = 'Author added successfully.';
        } catch (PDOException $e) { $error = 'Error adding author.'; }
    }
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $check = $dbh->prepare("SELECT COUNT(*) FROM tbl_books WHERE author_id=:id");
    $check->execute([':id'=>$id]);
    if ($check->fetchColumn() > 0) {
        $error = 'Cannot delete: books exist by this author.';
    } else {
        $dbh->prepare("DELETE FROM tbl_authors WHERE id=:id")->execute([':id'=>$id]);
        $success = 'Author deleted.';
    }
}

if (isset($_POST['edit'])) {
    $id   = (int)$_POST['edit_id'];
    $name = trim($_POST['edit_name'] ?? '');
    if ($name) {
        $dbh->prepare("UPDATE tbl_authors SET author_name=:n WHERE id=:id")->execute([':n'=>$name,':id'=>$id]);
        $success = 'Author updated.';
    }
}

$authors = $dbh->query("SELECT a.*, COUNT(b.id) as book_count FROM tbl_authors a LEFT JOIN tbl_books b ON b.author_id=a.id GROUP BY a.id ORDER BY a.id DESC")->fetchAll();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title"><h2>Manage Authors</h2><p>Add and update book authors</p></div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="row">
    <div class="col-6" style="max-width:380px;">
        <div class="el-card">
            <div class="el-card-header">➕ Add Author</div>
            <div class="el-card-body">
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Author Name *</label>
                        <input type="text" name="author_name" class="form-control" placeholder="e.g. Robert C. Martin" required>
                    </div>
                    <button type="submit" name="add" class="btn btn-primary btn-full">Add Author</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-6" style="flex:1;">
        <div class="el-card">
            <div class="el-card-header">✍️ All Authors (<?= count($authors) ?>)</div>
            <div class="p-0">
                <?php if ($authors): ?>
                <table class="el-table">
                    <thead><tr><th>#</th><th>Author Name</th><th>Books</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php $n=1; foreach ($authors as $a): ?>
                        <tr>
                            <td><?= $n++ ?></td>
                            <td>
                                <form method="POST" style="display:flex;gap:6px;align-items:center;">
                                    <input type="hidden" name="edit_id" value="<?= $a->id ?>">
                                    <input type="text" name="edit_name" class="form-control" value="<?= htmlspecialchars($a->author_name) ?>" style="padding:5px 8px;font-size:13px;">
                                    <button type="submit" name="edit" class="btn btn-warning btn-sm">💾</button>
                                </form>
                            </td>
                            <td><span class="badge badge-primary"><?= $a->book_count ?></span></td>
                            <td>
                                <a href="?delete=<?= $a->id ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this author?')">🗑️</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="no-data">No authors yet.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
