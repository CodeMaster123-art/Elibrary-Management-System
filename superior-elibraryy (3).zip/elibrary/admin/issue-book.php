<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Issue Book';

$error = $success = '';
$loanDays = (int)getSetting('loan_days');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $book_id    = (int)($_POST['book_id'] ?? 0);
    $student_id = (int)($_POST['student_id'] ?? 0);
    $issue_date = $_POST['issue_date'] ?? date('Y-m-d');
    $due_date   = date('Y-m-d', strtotime($issue_date . " +$loanDays days"));

    // Check availability
    $bookStmt = $dbh->prepare("SELECT * FROM tbl_books WHERE id=:id AND status=1");
    $bookStmt->execute([':id'=>$book_id]);
    $book = $bookStmt->fetch();

    if (!$book) {
        $error = 'Book not found or inactive.';
    } elseif ($book->available_qty < 1) {
        $error = 'No copies available for this book.';
    } else {
        // Check if student already has this book
        $dupStmt = $dbh->prepare("SELECT id FROM tbl_issues WHERE book_id=:bid AND student_id=:sid AND status='issued'");
        $dupStmt->execute([':bid'=>$book_id, ':sid'=>$student_id]);
        if ($dupStmt->fetch()) {
            $error = 'This student already has this book issued.';
        } else {
            $stmt = $dbh->prepare("INSERT INTO tbl_issues (book_id, student_id, issue_date, due_date, issued_by) VALUES (:bid, :sid, :iss, :due, :admin)");
            $stmt->execute([':bid'=>$book_id, ':sid'=>$student_id, ':iss'=>$issue_date, ':due'=>$due_date, ':admin'=>$_SESSION['admin_id']]);

            // Decrease available qty
            $dbh->prepare("UPDATE tbl_books SET available_qty = available_qty - 1 WHERE id=:id")->execute([':id'=>$book_id]);
            $success = "Book issued successfully! Due date: " . date('d M Y', strtotime($due_date));
        }
    }
}

$books    = $dbh->query("SELECT * FROM tbl_books WHERE status=1 AND available_qty>0 ORDER BY book_name")->fetchAll();
$students = $dbh->query("SELECT * FROM tbl_students WHERE status=1 ORDER BY full_name")->fetchAll();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title"><h2>Issue Physical Book</h2><p>Issue a physical book copy to a student — this does not affect e-book access</p></div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="row">
    <div class="col-6" style="max-width:520px;">
        <div class="el-card">
            <div class="el-card-header">📤 Issue Physical Book to Student</div>
            <div class="el-card-body">
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Select Book *</label>
                        <select name="book_id" class="form-control" required>
                            <option value="">-- Select Available Book --</option>
                            <?php foreach ($books as $b): ?>
                            <option value="<?= $b->id ?>"><?= htmlspecialchars($b->book_name) ?> (<?= $b->available_qty ?> available)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Select Student *</label>
                        <select name="student_id" class="form-control" required>
                            <option value="">-- Select Student --</option>
                            <?php foreach ($students as $s): ?>
                            <option value="<?= $s->id ?>"><?= htmlspecialchars($s->full_name) ?> (<?= htmlspecialchars($s->student_id) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Issue Date *</label>
                        <input type="date" name="issue_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="alert alert-info" style="font-size:13px;">
                        📦 This is for <strong>physical book borrowing only</strong>. E-books can always be read/downloaded freely.
                        📅 Due date: <strong><?= $loanDays ?> days</strong> from issue. Fine: <strong>₨<?= getSetting('fine_per_day') ?>/day</strong> if overdue.
                    </div>
                    <button type="submit" class="btn btn-success btn-full">📤 Issue Book</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-6" style="flex:1;">
        <div class="el-card">
            <div class="el-card-header">📋 Today's Issues</div>
            <div class="p-0">
                <?php
                $todayIssues = $dbh->query("
                    SELECT i.*, b.book_name, s.full_name as student_name, s.student_id as sid
                    FROM tbl_issues i
                    JOIN tbl_books b ON b.id=i.book_id
                    JOIN tbl_students s ON s.id=i.student_id
                    WHERE DATE(i.created_at)=CURDATE()
                    ORDER BY i.id DESC
                ")->fetchAll();
                ?>
                <?php if ($todayIssues): ?>
                <table class="el-table">
                    <thead><tr><th>Book</th><th>Student</th><th>Due Date</th></tr></thead>
                    <tbody>
                        <?php foreach ($todayIssues as $t): ?>
                        <tr>
                            <td><?= htmlspecialchars(substr($t->book_name,0,28)) ?>...</td>
                            <td><?= htmlspecialchars($t->student_name) ?><br><small class="text-muted"><?= $t->sid ?></small></td>
                            <td><?= date('d M Y', strtotime($t->due_date)) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="no-data">No books issued today.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
