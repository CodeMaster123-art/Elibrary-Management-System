<?php
if (!defined('IN_ADMIN')) {
    session_start();
    if (empty($_SESSION['admin_id'])) {
        header('Location: ' . (strpos($_SERVER['PHP_SELF'], '/admin/') !== false ? 'login.php' : 'admin/login.php'));
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' | ' : ''; ?>Admin — Superior E-Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { margin: 0; display: flex; flex-direction: column; min-height: 100vh; }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="el-header">
    <a href="dashboard.php" class="brand">
        <img src="../assets/img/logo.png" alt="Logo">
        <span class="brand-text">Superior E-Library</span>
    </a>
    <div class="header-right">
        <div class="user-badge">🛡️ <?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?></div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</header>

<div class="el-layout">

<!-- SIDEBAR -->
<nav class="el-sidebar">
    <div class="nav-section">Dashboard</div>
    <a href="dashboard.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':''; ?>">
        <span class="icon">📊</span> Dashboard
    </a>

    <div class="nav-section">Books</div>
    <a href="manage-books.php" class="nav-item <?php echo in_array(basename($_SERVER['PHP_SELF']),['manage-books.php','add-book.php','edit-book.php'])?'active':''; ?>">
        <span class="icon">📚</span> Manage Books
    </a>
    <a href="add-book.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])=='add-book.php'?'active':''; ?>">
        <span class="icon">➕</span> Add Book
    </a>
    <a href="manage-categories.php" class="nav-item <?php echo in_array(basename($_SERVER['PHP_SELF']),['manage-categories.php','add-category.php'])?'active':''; ?>">
        <span class="icon">🏷️</span> Categories
    </a>
    <a href="manage-authors.php" class="nav-item <?php echo in_array(basename($_SERVER['PHP_SELF']),['manage-authors.php','add-author.php'])?'active':''; ?>">
        <span class="icon">✍️</span> Authors
    </a>

    <div class="nav-section">Library</div>
    <a href="issue-book.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])=='issue-book.php'?'active':''; ?>">
        <span class="icon">📤</span> Issue Physical Book
    </a>
    <a href="return-book.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])=='return-book.php'?'active':''; ?>">
        <span class="icon">📥</span> Return Physical Book
    </a>
    <a href="issued-books.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])=='issued-books.php'?'active':''; ?>">
        <span class="icon">📋</span> Physical Issue Log
    </a>
    <a href="manage-fines.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])=='manage-fines.php'?'active':''; ?>">
        <span class="icon">💰</span> Manage Fines
    </a>

    <div class="nav-section">Users</div>
    <a href="manage-students.php" class="nav-item <?php echo in_array(basename($_SERVER['PHP_SELF']),['manage-students.php','view-student.php','edit-student.php'])?'active':''; ?>">
        <span class="icon">👥</span> Students
    </a>
    <a href="student-activity.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])=='student-activity.php'?'active':''; ?>">
    <a href="add-student.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])=='add-student.php'?'active':''; ?>">
        <span class="icon">➕</span> Add Student
    </a>
        <span class="icon">📈</span> Activity Log
    </a>

    <div class="nav-section">System</div>
    <a href="settings.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])=='settings.php'?'active':''; ?>">
        <span class="icon">⚙️</span> Settings
    </a>
    <a href="../index.php" class="nav-item">
        <span class="icon">🏠</span> Main Site
    </a>
</nav>

<main class="el-main">
