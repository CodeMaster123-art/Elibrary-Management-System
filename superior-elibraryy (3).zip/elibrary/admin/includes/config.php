<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'elibrary');

try {
    $dbh = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
        ]
    );
} catch (PDOException $e) {
    die("<div style='font-family:sans-serif;padding:40px;text-align:center;'>
        <h2 style='color:#4b2c5e;'>Database Connection Failed</h2>
        <p style='color:#666;'>Please ensure XAMPP MySQL is running and import <strong>database.sql</strong></p>
        <p style='color:#999;font-size:12px;'>" . $e->getMessage() . "</p>
    </div>");
}

// Helper: get setting
function getSetting($key) {
    global $dbh;
    $stmt = $dbh->prepare("SELECT setting_value FROM tbl_settings WHERE setting_key = :key");
    $stmt->execute([':key' => $key]);
    $row = $stmt->fetch();
    return $row ? $row->setting_value : null;
}
?>
