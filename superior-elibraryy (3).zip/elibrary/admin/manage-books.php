<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Manage Books';

// Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    // Get image to delete
    $stmt = $dbh->prepare("SELECT book_image FROM tbl_books WHERE id=:id");
    $stmt->execute([':id'=>$id]);
    $book = $stmt->fetch();
    if ($book && $book->book_image && file_exists(__DIR__ . "/bookimg/".$book->book_image)) {
        unlink(__DIR__ . "/bookimg/".$book->book_image);
    }
    $dbh->prepare("DELETE FROM tbl_books WHERE id=:id")->execute([':id'=>$id]);
    header('Location: manage-books.php?msg=deleted'); exit;
}

// Toggle status
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $dbh->prepare("UPDATE tbl_books SET status = 1 - status WHERE id=:id")->execute([':id'=>$id]);
    header('Location: manage-books.php'); exit;
}

$search = trim($_GET['s'] ?? '');
$params = [];
$sql = "SELECT b.*, c.category_name, a.author_name
        FROM tbl_books b
        LEFT JOIN tbl_categories c ON c.id = b.category_id
        LEFT JOIN tbl_authors a ON a.id = b.author_id";
if ($search) {
    $sql .= " WHERE b.book_name LIKE :s OR b.isbn LIKE :s2 OR a.author_name LIKE :s3";
    $params = [':s'=>"%$search%", ':s2'=>"%$search%", ':s3'=>"%$search%"];
}
$sql .= " ORDER BY b.id DESC";
$stmt = $dbh->prepare($sql); $stmt->execute($params);
$books = $stmt->fetchAll();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title d-flex justify-between align-center">
    <div><h2>Manage Books</h2><p>View, edit and delete library books</p></div>
    <a href="add-book.php" class="btn btn-primary">➕ Add New Book</a>
</div>

<?php if (isset($_GET['msg'])): ?>
<div class="alert alert-<?= $_GET['msg']==='deleted'?'danger':($_GET['msg']==='added'?'success':'info') ?>">
    <?= ['deleted'=>'Book deleted.','added'=>'Book added successfully!','updated'=>'Book updated.'][$_GET['msg']] ?? '' ?>
</div>
<?php endif; ?>

<div class="search-bar">
    <form method="GET" style="display:flex;gap:8px;flex:1;">
        <input type="text" name="s" placeholder="Search by title, ISBN, or author..." value="<?= htmlspecialchars($search) ?>">
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if ($search): ?><a href="manage-books.php" class="btn btn-secondary">Clear</a><?php endif; ?>
    </form>
</div>

<div class="el-card">
    <div class="el-card-header">📚 Books (<?= count($books) ?>)</div>
    <div class="p-0">
        <?php if ($books): ?>
        <table class="el-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cover</th>
                    <th>Book Name</th>
                    <th>Category</th>
                    <th>Author</th>
                    <th>ISBN</th>
                    <th>Qty</th>
                    <th>Avail.</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $n=1; foreach ($books as $b): ?>
                <tr>
                    <td><?= $n++ ?></td>
                    <td>
                        <?php if ($b->book_image && file_exists("bookimg/".$b->book_image)): ?>
                        <img src="bookimg/<?= htmlspecialchars($b->book_image) ?>" style="width:40px;height:52px;object-fit:cover;border-radius:4px;">
                        <?php else: ?>
                        <div style="width:40px;height:52px;background:#e8d5f5;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:18px;">📗</div>
                        <?php endif; ?>
                    </td>
                    <td><strong><?= htmlspecialchars($b->book_name) ?></strong></td>
                    <td><?= htmlspecialchars($b->category_name ?? '—') ?></td>
                    <td><?= htmlspecialchars($b->author_name ?? '—') ?></td>
                    <td><small><?= htmlspecialchars($b->isbn) ?></small></td>
                    <td><?= $b->total_qty ?></td>
                    <td>
                        <?php if ($b->available_qty > 0): ?>
                            <span class="badge badge-success"><?= $b->available_qty ?></span>
                        <?php else: ?>
                            <span class="badge badge-danger">0</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="?toggle=<?= $b->id ?>" title="Toggle">
                            <?= $b->status ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>' ?>
                        </a>
                    </td>
                    <td>
                        <a href="edit-book.php?id=<?= $b->id ?>" class="btn btn-warning btn-sm">✏️</a>
                        <a href="?delete=<?= $b->id ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this book?')">🗑️</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="no-data">No books found. <a href="add-book.php">Add one?</a></div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
