<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Add Student';

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id'] ?? '');
    $full_name  = trim($_POST['full_name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $password   = $_POST['password'] ?? '';
    $confirm    = $_POST['confirm_password'] ?? '';

    if (empty($student_id) || empty($full_name) || empty($email) || empty($password)) {
        $error = 'Please fill all required fields.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        try {
            $stmt = $dbh->prepare("INSERT INTO tbl_students (student_id, full_name, email, phone, department, password, status)
                                   VALUES (:sid, :name, :email, :phone, :dept, :pass, 1)");
            $stmt->execute([
                ':sid'   => $student_id,
                ':name'  => $full_name,
                ':email' => $email,
                ':phone' => $phone,
                ':dept'  => $department,
                ':pass'  => $hashed
            ]);
            $success = "Student <strong>" . htmlspecialchars($full_name) . "</strong> added successfully! They can now login with email <strong>" . htmlspecialchars($email) . "</strong>.";
        } catch (PDOException $e) {
            $error = 'Student ID or Email already exists. Please use a unique value.';
        }
    }
}
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title d-flex justify-between align-center">
    <div><h2>Add Student</h2><p>Create a new student library account</p></div>
    <a href="manage-students.php" class="btn btn-secondary">← Back to Students</a>
</div>

<?php if ($error):   ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= $success ?> <a href="add-student.php">Add another?</a></div><?php endif; ?>

<div class="row">
    <div class="col-6" style="max-width:560px;">
        <div class="el-card">
            <div class="el-card-header">👤 Student Information</div>
            <div class="el-card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Student ID / Roll No. <span style="color:red">*</span></label>
                                <input type="text" name="student_id" class="form-control" placeholder="e.g. SUP-2024-001" required value="<?= htmlspecialchars($_POST['student_id'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Full Name <span style="color:red">*</span></label>
                                <input type="text" name="full_name" class="form-control" placeholder="Student full name" required value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Email Address <span style="color:red">*</span></label>
                                <input type="email" name="email" class="form-control" placeholder="student@university.edu" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                                <small class="text-muted">Used to login</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Phone Number</label>
                                <input type="text" name="phone" class="form-control" placeholder="03XX-XXXXXXX" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">Department / Program</label>
                                <input type="text" name="department" class="form-control" placeholder="e.g. BS Computer Science" value="<?= htmlspecialchars($_POST['department'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Password <span style="color:red">*</span></label>
                                <input type="password" name="password" class="form-control" placeholder="Min 6 characters" required>
                                <small class="text-muted">Share this with the student</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Confirm Password <span style="color:red">*</span></label>
                                <input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required>
                            </div>
                        </div>
                    </div>
                    <div style="display:flex;gap:10px;margin-top:8px;">
                        <button type="submit" class="btn btn-primary">➕ Add Student</button>
                        <a href="manage-students.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-6" style="flex:1;">
        <div class="el-card">
            <div class="el-card-header">ℹ️ Instructions</div>
            <div class="el-card-body">
                <p style="font-size:13px;color:#555;line-height:1.8;margin-bottom:16px;">
                    Students are added by the admin only. Once added, the student can log in at:<br>
                    <code style="background:#f5f0fa;padding:4px 8px;border-radius:4px;font-size:12px;">http://localhost/elibrary/student/login.php</code>
                </p>
                <p style="font-size:13px;color:#555;line-height:1.8;margin-bottom:16px;">
                    Using the <strong>email</strong> and <strong>password</strong> you set here.
                </p>
                <div style="background:#fef0d9;border-left:4px solid #e67e22;padding:12px;border-radius:6px;font-size:13px;color:#935116;">
                    ⚠️ Make sure to note down the password and share it with the student. Passwords are stored encrypted and cannot be retrieved — only reset.
                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
