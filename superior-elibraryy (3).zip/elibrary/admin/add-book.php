<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Add Book';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $book_name   = trim($_POST['book_name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $author_id   = (int)($_POST['author_id'] ?? 0);
    $isbn        = trim($_POST['isbn'] ?? '');
    $total_qty   = (int)($_POST['total_qty'] ?? 1);
    $description = trim($_POST['description'] ?? '');
    $book_image  = '';
    $ebook_file  = '';

    // Image upload
    if (!empty($_FILES['book_image']['name'])) {
        $ext = strtolower(pathinfo($_FILES['book_image']['name'], PATHINFO_EXTENSION));
        $allowed_img = ['jpg','jpeg','png','gif','webp'];
        if (!in_array($ext, $allowed_img)) {
            $error = 'Invalid image format. Allowed: jpg, png, gif, webp';
        } else {
            $book_image = md5(uniqid()) . '.' . $ext;
            move_uploaded_file($_FILES['book_image']['tmp_name'], __DIR__ . '/bookimg/' . $book_image);
        }
    }

    // E-book PDF upload
    if (!$error && !empty($_FILES['ebook_file']['name'])) {
        $ext2 = strtolower(pathinfo($_FILES['ebook_file']['name'], PATHINFO_EXTENSION));
        if ($ext2 !== 'pdf') {
            $error = 'E-book must be a PDF file.';
        } else {
            if (!is_dir(dirname(__DIR__) . '/assets/ebooks')) mkdir(dirname(__DIR__) . '/assets/ebooks', 0755, true);
            $ebook_file = md5(uniqid()) . '.pdf';
            move_uploaded_file($_FILES['ebook_file']['tmp_name'], dirname(__DIR__) . '/assets/ebooks/' . $ebook_file);
        }
    }

    if (!$error) {
        try {
            $stmt = $dbh->prepare("INSERT INTO tbl_books (book_name, category_id, author_id, isbn, book_image, total_qty, available_qty, ebook_file, description)
                                   VALUES (:bn, :cat, :auth, :isbn, :img, :qty, :qty2, :ebook, :desc)");
            $stmt->execute([
                ':bn'=>$book_name, ':cat'=>$category_id, ':auth'=>$author_id,
                ':isbn'=>$isbn, ':img'=>$book_image,
                ':qty'=>$total_qty, ':qty2'=>$total_qty, ':ebook'=>$ebook_file, ':desc'=>$description
            ]);
            header('Location: manage-books.php?msg=added'); exit;
        } catch (PDOException $e) {
            $error = 'ISBN already exists or database error: ' . $e->getMessage();
        }
    }
}

$categories = $dbh->query("SELECT * FROM tbl_categories WHERE status=1 ORDER BY category_name")->fetchAll();
$authors    = $dbh->query("SELECT * FROM tbl_authors ORDER BY author_name")->fetchAll();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title">
    <h2>Add New Book</h2>
    <p>Fill in the book details below</p>
</div>

<?php if ($error): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="el-card">
    <div class="el-card-header">📗 Book Information</div>
    <div class="el-card-body">
        <form method="POST" enctype="multipart/form-data">

            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">Book Name <span style="color:red">*</span></label>
                        <input type="text" name="book_name" class="form-control" placeholder="Enter book title" required value="<?= htmlspecialchars($_POST['book_name'] ?? '') ?>">
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">ISBN Number <span style="color:red">*</span></label>
                        <input type="text" name="isbn" class="form-control" placeholder="e.g. 978-3-16-148410-0" required value="<?= htmlspecialchars($_POST['isbn'] ?? '') ?>">
                        <small class="text-muted">Must be unique per book</small>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">Category <span style="color:red">*</span></label>
                        <select name="category_id" class="form-control" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $c): ?>
                            <option value="<?= $c->id ?>" <?= (($_POST['category_id']??'')==$c->id)?'selected':'' ?>><?= htmlspecialchars($c->category_name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">Author <span style="color:red">*</span></label>
                        <select name="author_id" class="form-control" required>
                            <option value="">Select Author</option>
                            <?php foreach ($authors as $a): ?>
                            <option value="<?= $a->id ?>" <?= (($_POST['author_id']??'')==$a->id)?'selected':'' ?>><?= htmlspecialchars($a->author_name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">Total Quantity <span style="color:red">*</span></label>
                        <input type="number" name="total_qty" class="form-control" placeholder="1" min="1" required value="<?= htmlspecialchars($_POST['total_qty'] ?? '1') ?>">
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">Book Cover Image</label>
                        <input type="file" name="book_image" class="form-control" accept="image/*">
                        <small class="text-muted">Supported: jpg, png, gif, webp</small>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">E-Book File (PDF)</label>
                        <input type="file" name="ebook_file" class="form-control" accept=".pdf">
                        <small class="text-muted">Upload PDF so students can read/download online</small>
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="4" placeholder="Brief description of the book..."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>

            <div style="display:flex;gap:10px;margin-top:8px;">
                <button type="submit" class="btn btn-primary">📗 Add Book</button>
                <a href="manage-books.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
