<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Manage Fines';

$success = $error = '';

// Mark fine as paid
if (isset($_GET['pay'])) {
    $id = (int)$_GET['pay'];
    $dbh->prepare("UPDATE tbl_issues SET fine_paid=1 WHERE id=:id")->execute([':id'=>$id]);
    $success = 'Fine marked as paid.';
}

// Waive fine
if (isset($_GET['waive'])) {
    $id = (int)$_GET['waive'];
    $dbh->prepare("UPDATE tbl_issues SET fine_amount=0, fine_paid=0 WHERE id=:id")->execute([':id'=>$id]);
    $success = 'Fine waived.';
}

$finePerDay = (float)getSetting('fine_per_day');

// Update overdue fines for active issues
$dbh->query("UPDATE tbl_issues SET fine_amount = DATEDIFF(CURDATE(), due_date) * $finePerDay
             WHERE status='issued' AND due_date < CURDATE()");

$filter = $_GET['filter'] ?? 'unpaid';
$sql = "SELECT i.*, b.book_name, s.full_name as student_name, s.student_id as sid,
               DATEDIFF(CURDATE(), i.due_date) as days_overdue
        FROM tbl_issues i
        JOIN tbl_books b ON b.id=i.book_id
        JOIN tbl_students s ON s.id=i.student_id
        WHERE i.fine_amount > 0";
if ($filter === 'unpaid') $sql .= " AND i.fine_paid=0";
if ($filter === 'paid')   $sql .= " AND i.fine_paid=1";
$sql .= " ORDER BY i.fine_amount DESC";
$fines = $dbh->query($sql)->fetchAll();

$totalUnpaid = $dbh->query("SELECT COALESCE(SUM(fine_amount),0) FROM tbl_issues WHERE fine_paid=0 AND fine_amount>0")->fetchColumn();
$totalPaid   = $dbh->query("SELECT COALESCE(SUM(fine_amount),0) FROM tbl_issues WHERE fine_paid=1")->fetchColumn();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title"><h2>Manage Fines</h2><p>Track and collect overdue fines</p></div>

<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="stats-grid" style="grid-template-columns:repeat(3,1fr);">
    <div class="stat-card red">
        <div class="stat-icon">💸</div>
        <div><div class="stat-num">₨<?= number_format($totalUnpaid,0) ?></div><div class="stat-lbl">Unpaid Fines</div></div>
    </div>
    <div class="stat-card green">
        <div class="stat-icon">✅</div>
        <div><div class="stat-num">₨<?= number_format($totalPaid,0) ?></div><div class="stat-lbl">Collected</div></div>
    </div>
    <div class="stat-card orange">
        <div class="stat-icon">📅</div>
        <div><div class="stat-num">₨<?= $finePerDay ?>/day</div><div class="stat-lbl">Fine Rate</div></div>
    </div>
</div>

<div style="display:flex;gap:8px;margin-bottom:16px;">
    <a href="?filter=unpaid" class="btn <?= $filter==='unpaid'?'btn-primary':'btn-secondary' ?>">Unpaid</a>
    <a href="?filter=paid"   class="btn <?= $filter==='paid'  ?'btn-primary':'btn-secondary' ?>">Paid</a>
    <a href="?filter=all"    class="btn <?= $filter==='all'   ?'btn-primary':'btn-secondary' ?>">All</a>
</div>

<div class="el-card">
    <div class="el-card-header">💰 Fines (<?= count($fines) ?>)</div>
    <div class="p-0">
        <?php if ($fines): ?>
        <table class="el-table">
            <thead>
                <tr><th>#</th><th>Student</th><th>Book</th><th>Due Date</th><th>Days Late</th><th>Fine Amount</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php $n=1; foreach ($fines as $f): ?>
                <tr>
                    <td><?= $n++ ?></td>
                    <td><?= htmlspecialchars($f->student_name) ?><br><small class="text-muted"><?= htmlspecialchars($f->sid) ?></small></td>
                    <td><?= htmlspecialchars($f->book_name) ?></td>
                    <td><?= date('d M Y', strtotime($f->due_date)) ?></td>
                    <td>
                        <?php
                        if ($f->return_date) {
                            $days = max(0, (strtotime($f->return_date) - strtotime($f->due_date)) / 86400);
                        } else {
                            $days = max(0, $f->days_overdue);
                        }
                        echo '<span class="badge badge-danger">' . (int)$days . ' days</span>';
                        ?>
                    </td>
                    <td class="text-danger fw-bold">₨<?= number_format($f->fine_amount,0) ?></td>
                    <td>
                        <?= $f->fine_paid
                            ? '<span class="badge badge-success">Paid</span>'
                            : '<span class="badge badge-danger">Unpaid</span>' ?>
                    </td>
                    <td>
                        <?php if (!$f->fine_paid): ?>
                        <a href="?pay=<?= $f->id ?>&filter=<?= $filter ?>" class="btn btn-success btn-sm" onclick="return confirm('Mark as paid?')">✅ Paid</a>
                        <a href="?waive=<?= $f->id ?>&filter=<?= $filter ?>" class="btn btn-warning btn-sm" onclick="return confirm('Waive this fine?')">🎁 Waive</a>
                        <?php else: ?>
                        <span class="text-muted" style="font-size:12px;">Settled</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="no-data">No <?= $filter !== 'all' ? $filter : '' ?> fines found. ✅</div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
