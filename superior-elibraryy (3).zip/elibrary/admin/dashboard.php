<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Dashboard';

// Stats
$totalBooks    = $dbh->query("SELECT COUNT(*) FROM tbl_books")->fetchColumn();
$totalStudents = $dbh->query("SELECT COUNT(*) FROM tbl_students")->fetchColumn();
$activeIssues  = $dbh->query("SELECT COUNT(*) FROM tbl_issues WHERE status='issued'")->fetchColumn();
$overdueIssues = $dbh->query("SELECT COUNT(*) FROM tbl_issues WHERE status='issued' AND due_date < CURDATE()")->fetchColumn();
$totalFine     = $dbh->query("SELECT COALESCE(SUM(fine_amount),0) FROM tbl_issues WHERE fine_paid=0 AND fine_amount>0")->fetchColumn();
$totalCategories = $dbh->query("SELECT COUNT(*) FROM tbl_categories")->fetchColumn();

// Recent issues
$recentIssues = $dbh->query("
    SELECT i.*, b.book_name, s.full_name as student_name, s.student_id as sid
    FROM tbl_issues i
    JOIN tbl_books b ON b.id = i.book_id
    JOIN tbl_students s ON s.id = i.student_id
    ORDER BY i.created_at DESC LIMIT 8
")->fetchAll();

// Overdue list
$overdueList = $dbh->query("
    SELECT i.*, b.book_name, s.full_name as student_name, s.student_id as sid,
           DATEDIFF(CURDATE(), i.due_date) as days_overdue
    FROM tbl_issues i
    JOIN tbl_books b ON b.id = i.book_id
    JOIN tbl_students s ON s.id = i.student_id
    WHERE i.status='issued' AND i.due_date < CURDATE()
    ORDER BY days_overdue DESC LIMIT 5
")->fetchAll();

$finePerDay = getSetting('fine_per_day');
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title">
    <h2>Dashboard</h2>
    <p>Welcome back, <?= htmlspecialchars($_SESSION['admin_name']) ?> — here's your library overview</p>
</div>

<!-- STAT CARDS -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">📚</div>
        <div>
            <div class="stat-num"><?= $totalBooks ?></div>
            <div class="stat-lbl">Total Books</div>
        </div>
    </div>
    <div class="stat-card green">
        <div class="stat-icon">👥</div>
        <div>
            <div class="stat-num"><?= $totalStudents ?></div>
            <div class="stat-lbl">Registered Students</div>
        </div>
    </div>
    <div class="stat-card blue">
        <div class="stat-icon">📤</div>
        <div>
            <div class="stat-num"><?= $activeIssues ?></div>
            <div class="stat-lbl">Books Issued</div>
        </div>
    </div>
    <div class="stat-card red">
        <div class="stat-icon">⚠️</div>
        <div>
            <div class="stat-num"><?= $overdueIssues ?></div>
            <div class="stat-lbl">Overdue Books</div>
        </div>
    </div>
    <div class="stat-card orange">
        <div class="stat-icon">💰</div>
        <div>
            <div class="stat-num">₨<?= number_format($totalFine, 0) ?></div>
            <div class="stat-lbl">Pending Fines</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">🏷️</div>
        <div>
            <div class="stat-num"><?= $totalCategories ?></div>
            <div class="stat-lbl">Categories</div>
        </div>
    </div>
</div>

<!-- QUICK ACTIONS -->
<div class="el-card" style="margin-bottom:24px;">
    <div class="el-card-header">⚡ Quick Actions</div>
    <div class="el-card-body" style="display:flex;flex-wrap:wrap;gap:10px;">
        <a href="add-book.php" class="btn btn-primary">➕ Add Book</a>
        <a href="issue-book.php" class="btn btn-success">📤 Issue Book</a>
        <a href="return-book.php" class="btn btn-warning">📥 Return Book</a>
        <a href="manage-fines.php" class="btn btn-danger">💰 Manage Fines</a>
        <a href="manage-students.php" class="btn btn-info">👥 View Students</a>
    </div>
</div>

<div class="row">

    <!-- RECENT ISSUES -->
    <div class="col-6">
        <div class="el-card">
            <div class="el-card-header">
                📋 Recent Issues
                <a href="issued-books.php" style="color:rgba(255,255,255,0.8);font-size:12px;">View All</a>
            </div>
            <div class="p-0">
                <?php if ($recentIssues): ?>
                <table class="el-table">
                    <thead>
                        <tr><th>Book</th><th>Student</th><th>Due Date</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentIssues as $i): ?>
                        <?php $overdue = ($i->status === 'issued' && $i->due_date < date('Y-m-d')); ?>
                        <tr <?= $overdue ? 'class="row-overdue"' : '' ?>>
                            <td><?= htmlspecialchars(substr($i->book_name, 0, 25)) ?>...</td>
                            <td><?= htmlspecialchars($i->student_name) ?></td>
                            <td><?= date('d M Y', strtotime($i->due_date)) ?></td>
                            <td>
                                <?php if ($i->status === 'returned'): ?>
                                    <span class="badge badge-success">Returned</span>
                                <?php elseif ($overdue): ?>
                                    <span class="badge badge-danger">Overdue</span>
                                <?php else: ?>
                                    <span class="badge badge-info">Issued</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="no-data">No issues yet.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- OVERDUE LIST -->
    <div class="col-6">
        <div class="el-card">
            <div class="el-card-header" style="background:#c0392b;">
                ⚠️ Overdue Books
                <a href="manage-fines.php" style="color:rgba(255,255,255,0.8);font-size:12px;">Manage Fines</a>
            </div>
            <?php if ($overdueList): ?>
            <div class="p-0">
                <table class="el-table">
                    <thead>
                        <tr><th>Student</th><th>Book</th><th>Days Late</th><th>Fine</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($overdueList as $o): ?>
                        <tr>
                            <td><?= htmlspecialchars($o->student_name) ?><br><small class="text-muted"><?= $o->sid ?></small></td>
                            <td><?= htmlspecialchars(substr($o->book_name, 0, 22)) ?>...</td>
                            <td><span class="badge badge-danger"><?= $o->days_overdue ?> days</span></td>
                            <td class="text-danger fw-bold">₨<?= $o->days_overdue * $finePerDay ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="no-data">✅ No overdue books!</div>
            <?php endif; ?>
        </div>
    </div>

</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
