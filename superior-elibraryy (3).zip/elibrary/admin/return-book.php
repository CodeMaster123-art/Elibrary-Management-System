<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Return Book';

$error = $success = '';
$finePerDay = (float)getSetting('fine_per_day');

// Process return
if (isset($_POST['return'])) {
    $issue_id   = (int)$_POST['issue_id'];
    $return_date = $_POST['return_date'] ?? date('Y-m-d');

    $stmt = $dbh->prepare("SELECT i.*, b.id as bid FROM tbl_issues i JOIN tbl_books b ON b.id=i.book_id WHERE i.id=:id AND i.status='issued'");
    $stmt->execute([':id'=>$issue_id]);
    $issue = $stmt->fetch();

    if (!$issue) {
        $error = 'Issue record not found or already returned.';
    } else {
        // Calculate fine
        $dueDate    = new DateTime($issue->due_date);
        $retDate    = new DateTime($return_date);
        $daysLate   = max(0, $dueDate->diff($retDate)->days * ($retDate > $dueDate ? 1 : -1));
        $fine       = $daysLate * $finePerDay;

        $upd = $dbh->prepare("UPDATE tbl_issues SET return_date=:rd, fine_amount=:fine, status='returned' WHERE id=:id");
        $upd->execute([':rd'=>$return_date, ':fine'=>$fine, ':id'=>$issue_id]);

        // Restore availability
        $dbh->prepare("UPDATE tbl_books SET available_qty = available_qty + 1 WHERE id=:id")->execute([':id'=>$issue->bid]);

        $success = "Book returned successfully!" . ($fine > 0 ? " Fine charged: ₨$fine ($daysLate days late)" : " Returned on time.");
    }
}

// Active issues list
$search = trim($_GET['s'] ?? '');
$params = [];
$sql = "SELECT i.*, b.book_name, s.full_name as student_name, s.student_id as sid,
               DATEDIFF(CURDATE(), i.due_date) as days_overdue
        FROM tbl_issues i
        JOIN tbl_books b ON b.id=i.book_id
        JOIN tbl_students s ON s.id=i.student_id
        WHERE i.status='issued'";
if ($search) {
    $sql .= " AND (s.full_name LIKE :s OR s.student_id LIKE :s2 OR b.book_name LIKE :s3)";
    $params = [':s'=>"%$search%", ':s2'=>"%$search%", ':s3'=>"%$search%"];
}
$sql .= " ORDER BY i.due_date ASC";
$stmt = $dbh->prepare($sql); $stmt->execute($params);
$issues = $stmt->fetchAll();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title"><h2>Return Physical Book</h2><p>Process physical book returns and calculate fines — e-books are not affected</p></div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="search-bar">
    <form method="GET" style="display:flex;gap:8px;flex:1;">
        <input type="text" name="s" placeholder="Search by student name, ID or book title..." value="<?= htmlspecialchars($search) ?>">
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if ($search): ?><a href="return-book.php" class="btn btn-secondary">Clear</a><?php endif; ?>
    </form>
</div>

<div class="el-card">
    <div class="el-card-header">📥 Currently Issued Books (<?= count($issues) ?>)</div>
    <div class="p-0">
        <?php if ($issues): ?>
        <table class="el-table">
            <thead>
                <tr><th>#</th><th>Book</th><th>Student</th><th>Issue Date</th><th>Due Date</th><th>Status</th><th>Fine</th><th>Action</th></tr>
            </thead>
            <tbody>
                <?php $n=1; foreach ($issues as $i): ?>
                <?php $overdue = $i->days_overdue > 0; $calcFine = $overdue ? $i->days_overdue * $finePerDay : 0; ?>
                <tr <?= $overdue ? 'class="row-overdue"' : '' ?>>
                    <td><?= $n++ ?></td>
                    <td><?= htmlspecialchars($i->book_name) ?></td>
                    <td>
                        <?= htmlspecialchars($i->student_name) ?><br>
                        <small class="text-muted"><?= htmlspecialchars($i->sid) ?></small>
                    </td>
                    <td><?= date('d M Y', strtotime($i->issue_date)) ?></td>
                    <td><?= date('d M Y', strtotime($i->due_date)) ?></td>
                    <td>
                        <?php if ($overdue): ?>
                            <span class="badge badge-danger">⚠️ <?= $i->days_overdue ?>d overdue</span>
                        <?php else: ?>
                            <span class="badge badge-success">On Time</span>
                        <?php endif; ?>
                    </td>
                    <td class="<?= $calcFine > 0 ? 'text-danger fw-bold' : '' ?>">
                        <?= $calcFine > 0 ? '₨'.$calcFine : '—' ?>
                    </td>
                    <td>
                        <button class="btn btn-success btn-sm" onclick="openReturn(<?= $i->id ?>, '<?= htmlspecialchars(addslashes($i->book_name)) ?>', '<?= htmlspecialchars($i->student_name) ?>', '<?= $i->due_date ?>')">
                            📥 Return
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="no-data">No active issued books <?= $search ? 'matching your search.' : 'at the moment.' ?></div>
        <?php endif; ?>
    </div>
</div>

<!-- RETURN MODAL -->
<div id="returnModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:9999;align-items:center;justify-content:center;">
    <div style="background:white;border-radius:16px;padding:32px;width:420px;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
        <h3 style="color:#4b2c5e;margin-bottom:4px;">Return Book</h3>
        <p id="modalInfo" style="font-size:13px;color:#7a6b8a;margin-bottom:20px;"></p>
        <form method="POST">
            <input type="hidden" name="issue_id" id="modal_issue_id">
            <div class="form-group">
                <label class="form-label">Return Date</label>
                <input type="date" name="return_date" id="modal_return_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>
            <div id="finePreview" style="padding:10px;background:#fef0d9;border-radius:8px;margin-bottom:16px;font-size:13px;display:none;"></div>
            <div style="display:flex;gap:10px;">
                <button type="submit" name="return" class="btn btn-success" style="flex:1;">✅ Confirm Return</button>
                <button type="button" class="btn btn-secondary" onclick="closeReturn()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
var finePerDay = <?= $finePerDay ?>;
var issueDue   = {};

function openReturn(id, book, student, due) {
    issueDue[id] = due;
    document.getElementById('modal_issue_id').value = id;
    document.getElementById('modalInfo').textContent = book + ' — ' + student;
    document.getElementById('returnModal').style.display = 'flex';
    updateFine(id, due);
    document.getElementById('modal_return_date').onchange = function() { updateFine(id, due); };
}

function updateFine(id, due) {
    var retDate = new Date(document.getElementById('modal_return_date').value);
    var dueDate = new Date(due);
    var diff    = Math.ceil((retDate - dueDate) / (1000*60*60*24));
    var fp      = document.getElementById('finePreview');
    if (diff > 0) {
        fp.style.display = 'block';
        fp.innerHTML = '⚠️ <strong>' + diff + ' days late.</strong> Fine will be: <strong style="color:#c0392b">₨' + (diff * finePerDay) + '</strong>';
    } else {
        fp.style.display = 'none';
    }
}

function closeReturn() {
    document.getElementById('returnModal').style.display = 'none';
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
