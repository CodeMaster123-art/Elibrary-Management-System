<?php
define('IN_ADMIN', true);
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
include __DIR__ . '/includes/config.php';
$page_title = 'Manage Students';

$success = $error = '';

// Toggle status
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $dbh->prepare("UPDATE tbl_students SET status = 1 - status WHERE id=:id")->execute([':id'=>$id]);
    header('Location: manage-students.php'); exit;
}

// Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $check = $dbh->prepare("SELECT COUNT(*) FROM tbl_issues WHERE student_id=:id AND status='issued'");
    $check->execute([':id'=>$id]);
    if ($check->fetchColumn() > 0) {
        $error = 'Cannot delete: student has active issued books.';
    } else {
        $dbh->prepare("DELETE FROM tbl_students WHERE id=:id")->execute([':id'=>$id]);
        $success = 'Student deleted.';
    }
}

$search = trim($_GET['s'] ?? '');
$sql = "SELECT s.*, COUNT(CASE WHEN i.status='issued' THEN 1 END) as active_issues,
               COALESCE(SUM(CASE WHEN i.fine_paid=0 THEN i.fine_amount ELSE 0 END),0) as pending_fine
        FROM tbl_students s
        LEFT JOIN tbl_issues i ON i.student_id=s.id
        WHERE 1=1";
$params = [];
if ($search) {
    $sql .= " AND (s.full_name LIKE :s OR s.student_id LIKE :s2 OR s.email LIKE :s3)";
    $params = [':s'=>"%$search%",':s2'=>"%$search%",':s3'=>"%$search%"];
}
$sql .= " GROUP BY s.id ORDER BY s.id DESC";
$stmt = $dbh->prepare($sql); $stmt->execute($params);
$students = $stmt->fetchAll();
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title d-flex justify-between align-center"><div><h2>Manage Students</h2><p>View all registered students</p></div><a href="add-student.php" class="btn btn-primary">➕ Add New Student</a></div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="search-bar">
    <form method="GET" style="display:flex;gap:8px;flex:1;">
        <input type="text" name="s" placeholder="Search by name, student ID or email..." value="<?= htmlspecialchars($search) ?>">
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if ($search): ?><a href="manage-students.php" class="btn btn-secondary">Clear</a><?php endif; ?>
    </form>
</div>

<div class="el-card">
    <div class="el-card-header">👥 Students (<?= count($students) ?>)</div>
    <div class="p-0">
        <?php if ($students): ?>
        <table class="el-table">
            <thead>
                <tr><th>#</th><th>Student ID</th><th>Full Name</th><th>Email</th><th>Department</th><th>Issued</th><th>Fine</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php $n=1; foreach ($students as $s): ?>
                <tr>
                    <td><?= $n++ ?></td>
                    <td><strong><?= htmlspecialchars($s->student_id) ?></strong></td>
                    <td><?= htmlspecialchars($s->full_name) ?></td>
                    <td><small><?= htmlspecialchars($s->email) ?></small></td>
                    <td><small><?= htmlspecialchars($s->department ?: '—') ?></small></td>
                    <td>
                        <?php if ($s->active_issues > 0): ?>
                            <span class="badge badge-info"><?= $s->active_issues ?> book(s)</span>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($s->pending_fine > 0): ?>
                            <span class="text-danger fw-bold">₨<?= number_format($s->pending_fine,0) ?></span>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="?toggle=<?= $s->id ?>">
                            <?= $s->status ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>' ?>
                        </a>
                    </td>
                    <td>
                        <a href="view-student.php?id=<?= $s->id ?>" class="btn btn-info btn-sm">👁️</a>
                        <a href="edit-student.php?id=<?= $s->id ?>" class="btn btn-warning btn-sm">✏️</a>
                        <a href="?delete=<?= $s->id ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this student?')">🗑️</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="no-data">No students found.</div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
