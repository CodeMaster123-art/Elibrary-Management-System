<?php
define('IN_STUDENT', true);
session_start();
if (empty($_SESSION['student_id'])) { header('Location: login.php'); exit; }
require_once __DIR__ . '/includes/config.php';
$page_title = 'Dashboard';

$sid = (int)$_SESSION['student_id'];

$activeIssues = $dbh->prepare("SELECT COUNT(*) FROM tbl_issues WHERE student_id=:id AND status='issued'");
$activeIssues->execute([':id'=>$sid]);
$activeIssues = $activeIssues->fetchColumn();

$overdueCount = $dbh->prepare("SELECT COUNT(*) FROM tbl_issues WHERE student_id=:id AND status='issued' AND due_date < CURDATE()");
$overdueCount->execute([':id'=>$sid]);
$overdueCount = $overdueCount->fetchColumn();

$pendingFine = $dbh->prepare("SELECT COALESCE(SUM(fine_amount),0) FROM tbl_issues WHERE student_id=:id AND fine_paid=0");
$pendingFine->execute([':id'=>$sid]);
$pendingFine = $pendingFine->fetchColumn();

$totalBorrowed = $dbh->prepare("SELECT COUNT(*) FROM tbl_issues WHERE student_id=:id");
$totalBorrowed->execute([':id'=>$sid]);
$totalBorrowed = $totalBorrowed->fetchColumn();

$myIssues = $dbh->prepare("
    SELECT i.*, b.book_name, b.book_image, DATEDIFF(CURDATE(), i.due_date) as days_late
    FROM tbl_issues i JOIN tbl_books b ON b.id=i.book_id
    WHERE i.student_id=:id AND i.status='issued'
    ORDER BY i.due_date ASC
");
$myIssues->execute([':id'=>$sid]);
$myIssues = $myIssues->fetchAll();

$newBooks = $dbh->query("SELECT b.*, a.author_name, c.category_name FROM tbl_books b
    LEFT JOIN tbl_authors a ON a.id=b.author_id
    LEFT JOIN tbl_categories c ON c.id=b.category_id
    WHERE b.status=1 ORDER BY b.id DESC LIMIT 6")->fetchAll();

$finePerDay = (float)getSetting('fine_per_day');
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="page-title">
    <h2>Welcome, <?= htmlspecialchars($_SESSION['student_name']) ?>!</h2>
    <p>Your library dashboard — <?= date('l, d F Y') ?></p>
</div>

<div class="stats-grid">
    <div class="stat-card blue">
        <div class="stat-icon">📤</div>
        <div><div class="stat-num"><?= $activeIssues ?></div><div class="stat-lbl">Currently Borrowed</div></div>
    </div>
    <div class="stat-card red">
        <div class="stat-icon">⏰</div>
        <div><div class="stat-num"><?= $overdueCount ?></div><div class="stat-lbl">Overdue Books</div></div>
    </div>
    <div class="stat-card orange">
        <div class="stat-icon">💰</div>
        <div><div class="stat-num">₨<?= number_format($pendingFine,0) ?></div><div class="stat-lbl">Pending Fine</div></div>
    </div>
    <div class="stat-card green">
        <div class="stat-icon">📚</div>
        <div><div class="stat-num"><?= $totalBorrowed ?></div><div class="stat-lbl">Total Borrowed</div></div>
    </div>
</div>

<?php if ($overdueCount > 0): ?>
<div class="alert alert-danger">
    ⚠️ You have <strong><?= $overdueCount ?> overdue book(s)</strong>. Please return them to avoid additional fines (₨<?= $finePerDay ?>/day).
</div>
<?php endif; ?>

<div class="row">
    <div class="col-6">
        <div class="el-card">
            <div class="el-card-header">
                📋 My Current Books
                <a href="my-issues.php" style="color:rgba(255,255,255,0.8);font-size:12px;">View All</a>
            </div>
            <div class="p-0">
                <?php if ($myIssues): ?>
                <table class="el-table">
                    <thead><tr><th>Book</th><th>Due Date</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php foreach ($myIssues as $i): ?>
                        <?php $overdue = $i->days_late > 0; ?>
                        <tr <?= $overdue?'class="row-overdue"':'' ?>>
                            <td>
                                <div style="display:flex;align-items:center;gap:10px;">
                                    <?php if ($i->book_image && file_exists(dirname(__DIR__) . "/admin/bookimg/{$i->book_image}")): ?>
                                    <img src="../admin/bookimg/<?= htmlspecialchars($i->book_image) ?>" style="width:32px;height:42px;object-fit:cover;border-radius:3px;">
                                    <?php else: ?>
                                    <div style="width:32px;height:42px;background:#e8d5f5;border-radius:3px;display:flex;align-items:center;justify-content:center;">📗</div>
                                    <?php endif; ?>
                                    <span style="font-size:13px;"><?= htmlspecialchars($i->book_name) ?></span>
                                </div>
                            </td>
                            <td><?= date('d M Y', strtotime($i->due_date)) ?></td>
                            <td>
                                <?php if ($overdue): ?>
                                <span class="badge badge-danger"><?= $i->days_late ?>d late — ₨<?= $i->days_late * $finePerDay ?></span>
                                <?php else: ?>
                                <span class="badge badge-success">On Time</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="no-data">You have no physical books currently borrowed.<br><a href="browse-books.php">Browse the catalogue →</a></div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-6">
        <div class="el-card">
            <div class="el-card-header">
                🆕 Recently Added
                <a href="browse-books.php" style="color:rgba(255,255,255,0.8);font-size:12px;">Browse All</a>
            </div>
            <div class="el-card-body">
                <div class="books-grid" style="grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:14px;">
                    <?php foreach ($newBooks as $b): ?>
                    <div class="book-card">
                        <?php if ($b->book_image && file_exists(dirname(__DIR__) . "/admin/bookimg/{$b->book_image}")): ?>
                        <img src="../admin/bookimg/<?= htmlspecialchars($b->book_image) ?>" style="height:140px;">
                        <?php else: ?>
                        <div style="height:140px;background:linear-gradient(135deg,#e8d5f5,#d5c6e8);display:flex;align-items:center;justify-content:center;font-size:40px;">📗</div>
                        <?php endif; ?>
                        <div class="book-body">
                            <div class="book-title" style="font-size:12px;"><?= htmlspecialchars($b->book_name) ?></div>
                            <div class="book-author"><?= htmlspecialchars($b->author_name ?? '') ?></div>
                        </div>
                        <div class="book-actions">
                            <a href="browse-books.php?view=<?= $b->id ?>" class="btn btn-primary btn-sm" style="font-size:11px;padding:4px 8px;">View</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
