<?php
if (!defined('IN_STUDENT')) {
    session_start();
    if (empty($_SESSION['student_id'])) {
        header('Location: login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' | ' : ''; ?>Superior E-Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { margin: 0; display: flex; flex-direction: column; min-height: 100vh; }
    </style>
</head>
<body>

<header class="el-header">
    <a href="dashboard.php" class="brand">
        <img src="../assets/img/logo.png" alt="Logo">
        <span class="brand-text">Superior E-Library</span>
    </a>
    <div class="header-right">
        <div class="user-badge">📚 <?php echo htmlspecialchars($_SESSION['student_name'] ?? 'Student'); ?></div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</header>

<div class="el-layout">

<nav class="el-sidebar">
    <div class="nav-section">My Library</div>
    <a href="dashboard.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])==='dashboard.php'?'active':''; ?>">
        <span class="icon">🏠</span> Dashboard
    </a>
    <a href="browse-books.php" class="nav-item <?php echo in_array(basename($_SERVER['PHP_SELF']),['browse-books.php','read-book.php'])?'active':''; ?>">
        <span class="icon">📚</span> Browse Books
    </a>

    <div class="nav-section">My Account</div>
    <a href="my-issues.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])==='my-issues.php'?'active':''; ?>">
        <span class="icon">📦</span> My Borrowed Books
    </a>
    <a href="my-fines.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])==='my-fines.php'?'active':''; ?>">
        <span class="icon">💰</span> My Fines
    </a>
    <a href="my-profile.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF'])==='my-profile.php'?'active':''; ?>">
        <span class="icon">👤</span> My Profile
    </a>

    <div class="nav-section">Navigation</div>
    <a href="../index.php" class="nav-item">
        <span class="icon">🏛️</span> Home
    </a>
</nav>

<main class="el-main">
