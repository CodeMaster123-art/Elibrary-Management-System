</main>
</div>

<footer class="el-footer">
    © <?php echo date('Y'); ?> Superior University E-Library System
</footer>

</body>
</html>
